﻿using Employee_Registration_App.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace Employee_Registration_App.Controllers
{
    public class EmployeeController : Controller
    {
        EmployeeDataAccess _empdata = new EmployeeDataAccess();
        public IActionResult GetEmployees()
        {
          
            return View(_empdata.getEmployees().ToList());
        }

        public IActionResult UpdateEmployee()
        {
            return View();
        }
        public IActionResult DeleteEmployee() 
        {
            return View();
        }

        public IActionResult AddEmployee()
        {
            return View();
        }

    }
}
