﻿using Microsoft.Data.SqlClient;

namespace Employee_Registration_App.Models
{
    public class EmployeeDataAccess
    {
        const string ConnectionString = @"Data Source=MUKESH\\SQLEXPRESS;Initial Catalog=Employees;Integrated Security=True;Pooling=False;Encrypt=True;Trust Server Certificate=True";
        public EmployeeDataAccess()
        {
            
        }

        List<EmployeeDetails> Employees = new List<EmployeeDetails>();
        public List<EmployeeDetails> getEmployees()
        {
            
            SqlConnection objConnection = new SqlConnection(ConnectionString);
            SqlCommand cmd = objConnection.CreateCommand();
            cmd.CommandText = "Select * from Employee";
            objConnection.Open();
            try
            {
                var reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Employees.Add(new EmployeeDetails
                        {
                            // EmployeeID= reader.GetInt32(0),
                            EmployeeName = reader.GetString(1),
                            Email = reader.GetString(2),
                            DateOfBirth = reader.GetDateTime(3),
                            PhoneNumber = reader.GetString(4),
                            //Address=reader.GetString(5),


                        });

                    }

                }
            }
            catch (Exception ex) 
            {
                throw ex;
            }

            finally 
            {
                objConnection.Close();
            }
            return Employees; 
        }

        public bool AddEmployee(EmployeeDetails employee)
        {
            bool isInsertComplete = false;
            
            SqlConnection objConnection = new SqlConnection(ConnectionString);

            try
            {
                SqlCommand cmd = objConnection.CreateCommand();
                objConnection.Open();

                //cmd.CommandText = "Insert into Products values ( '" + Employees.EmployeeName + "','" + product.Category + "'," + product.UnitPrice +
                //                                        "," + product.Quantity + ")";
                
                isInsertComplete = (cmd.ExecuteNonQuery() > 0) ? true : false;



            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (objConnection.State == System.Data.ConnectionState.Open)
                    objConnection.Close();
            }
            return isInsertComplete;
        }

        public bool UpdateEmployee(int EmpID)
        {
            bool isUpdateCompleted = false;
            
            SqlConnection objConnection = new SqlConnection(ConnectionString);

            try
            {
                SqlCommand cmd = objConnection.CreateCommand();
                objConnection.Open();

                //cmd.CommandText = "Insert into Products values ( '" + Employees.EmployeeName + "','" + product.Category + "'," + product.UnitPrice +
                //                                        "," + product.Quantity + ")";

                isUpdateCompleted = (cmd.ExecuteNonQuery() > 0) ? true : false;



            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (objConnection.State == System.Data.ConnectionState.Open)
                    objConnection.Close();
            }
            return isUpdateCompleted;
        }

        public bool DeleteEmployee(int EmpID)   
        {
            bool isEmployeeDeleted = false;
            
            SqlConnection objConnection = new SqlConnection(ConnectionString);

            try
            {
                SqlCommand cmd = objConnection.CreateCommand();
                objConnection.Open();

                cmd.CommandText = "Delete from Employees where EmployeeID=" + EmpID;

                //isEmployeeDeleted = (cmd.ExecuteNonQuery() > 0) ? true : false;



            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (objConnection.State == System.Data.ConnectionState.Open)
                    objConnection.Close();
            }
            return isEmployeeDeleted;
        }

        public EmployeeDetails SearchEmployee(int EmpID)
        {
            
            var Employee = new EmployeeDetails();
            SqlConnection objConnection = new SqlConnection(ConnectionString);

            try
            {
                SqlCommand cmd = objConnection.CreateCommand();
                objConnection.Open();

                //cmd.CommandText = "Insert into Products values ( '" + Employees.EmployeeName + "','" + product.Category + "'," + product.UnitPrice +
                //                                        "," + product.Quantity + ")";

                //isInsertComplete = (cmd.ExecuteNonQuery() > 0) ? true : false;



            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (objConnection.State == System.Data.ConnectionState.Open)
                    objConnection.Close();
            }
            return Employee;
        }

    }
}
