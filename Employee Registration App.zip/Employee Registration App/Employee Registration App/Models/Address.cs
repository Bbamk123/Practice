﻿namespace Employee_Registration_App.Models
{
    public class Address
    {
        public string street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PIN { get; set; }
        public string Country { get; set; }
    }
}
